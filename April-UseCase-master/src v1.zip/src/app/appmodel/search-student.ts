export class SearchStudent {
}
