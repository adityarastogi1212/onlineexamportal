import { UserResponse } from './user-response';

describe('UserResponse', () => {
  it('should create an instance', () => {
    expect(new UserResponse()).toBeTruthy();
  });
});
