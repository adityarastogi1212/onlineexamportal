export class UserDetails {
}
