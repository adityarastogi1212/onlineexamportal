export class Question {
    question_id:any
    question:any;
    option_1:any;
    option_2:any;
    option_3:any;
    option_4:any;
    correct_option:any;
    courseId:any;
    levelId:any;
}

