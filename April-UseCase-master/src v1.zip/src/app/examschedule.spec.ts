import { Examschedule } from './examschedule';

describe('Examschedule', () => {
  it('should create an instance', () => {
    expect(new Examschedule()).toBeTruthy();
  });
});
