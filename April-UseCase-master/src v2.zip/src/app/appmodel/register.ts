export class Register {

    full_name: any;
    email: any;
    password:any;
    mobile:any;
    city:any;
    state:any;
    date_of_birth:any;
    qualification:any;
    year_of_completion:any;
}
