export class UserResponse {
    questionId:any;
    userAnswer:any;
}
