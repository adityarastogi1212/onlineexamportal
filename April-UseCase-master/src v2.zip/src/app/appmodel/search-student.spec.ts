import { SearchStudent } from './search-student';

describe('SearchStudent', () => {
  it('should create an instance', () => {
    expect(new SearchStudent()).toBeTruthy();
  });
});
