import { DeactivateGuard } from './deactive-guard';

describe('DeactiveGuard', () => {
  it('should create an instance', () => {
    expect(new DeactivateGuard()).toBeTruthy();
  });
});
