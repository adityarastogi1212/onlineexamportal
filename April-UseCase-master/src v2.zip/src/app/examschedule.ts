export class Examschedule {
    username: any
      useremail:any
      examtime!: Date
      levelid! : number
      courseid: any
  }
  