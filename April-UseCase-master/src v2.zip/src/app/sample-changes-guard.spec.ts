import { SampleChangesGuard } from './sample-changes-guard';

describe('SampleChangesGuard', () => {
  it('should create an instance', () => {
    expect(new SampleChangesGuard()).toBeTruthy();
  });
});
